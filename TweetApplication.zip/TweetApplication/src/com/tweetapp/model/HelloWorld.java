package com.tweetapp.model;

public class HelloWorld {

}
